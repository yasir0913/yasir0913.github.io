﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;

namespace WpfPaySorterSQLite
{
    
    class DBdata
    {        
        //current instance of DBdata
        static private SQLiteConnection cn;

        const string DB_FILE= "personnel.sqlite";

        public DBdata()
        {
           
            cn = new SQLiteConnection(DB_FILE, true);
            cn.CreateTable<Employee>();
        }

        #region public methods
        //Inserts Employee record into Employee table
        public int InsertEmployee()
        {
            if (cn.Table<Employee>().Count<Employee>() > 0)
            {
                cn.DeleteAll<Employee>();
            }

                List<Employee> newEmployees = new List<Employee>() {
                                    new Employee() {Name = "Sveta", Position = "Manager", PayRate = 55},
                                    new Employee() {Name = "Tanya", Position = "Clerk", PayRate = 60.5m },
                                    new Employee() {Name = "Masha", Position = "Clerk", PayRate = 45.80m },
                                    new Employee() {Name = "Tolya", Position = "Manager", PayRate = 40.70m},
                                    new Employee() {Name = "Roma", Position = "Manager", PayRate = 80.1m }
                };           

            return cn.InsertAll(newEmployees);                  
        }

        //Returns the list filled with Employee records
        public List<Employee> GetEmployee()
        {
            List<Employee> retEmployees = new List<Employee>();

            retEmployees = cn.Table<Employee>().ToList();

            return retEmployees;
        }     
        #endregion
    }
}
