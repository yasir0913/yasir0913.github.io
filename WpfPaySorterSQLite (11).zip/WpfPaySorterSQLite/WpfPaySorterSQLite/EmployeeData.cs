﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

//Team 2
// Vu Nguyen
// Oksana Blagutin
// Harsh Ahluwalia
// Arun Prabu
// Yasir Altahir
//Jon Plumbtree

namespace WpfPaySorterSQLite
{
    //enums for sorting
    public enum ESortOrder
    {
        DESC,
        ASC,
    }
    public enum ESortFiled
    {
        Name,
        Position,
        PayRate
    }

    //MVVM class 
    class EmployeeData: INotifyPropertyChanged
    {        
        
        private List<Employee> empList;
        DBdata db;

        public List<Employee> EmployeeList
        {
            get { return empList; }
            set {empList = value; OnPropertyChanged(); }
        }

        //Constructor - fills Employee list with db data
        public EmployeeData()
        {
            EmployeeList = new List<Employee>();           
            db = new DBdata();

            //Insert records
            db.InsertEmployee();        

            //Get records
            EmployeeList = db.GetEmployee();
        }

        //Sorts the list by parameters
        public void SortData(ESortOrder order=ESortOrder.ASC, ESortFiled field = ESortFiled.PayRate) 
        {
            List<Employee> sortedEmployee;            

            //Descending order
            if (order == ESortOrder.DESC)
            {
                switch(field)
                {
                    case ESortFiled.PayRate:
                        sortedEmployee = empList.OrderByDescending(em => em.PayRate).ToList();
                        break;
                    case ESortFiled.Name:
                        sortedEmployee = empList.OrderByDescending(em => em.Name).ToList();
                        break;
                    case ESortFiled.Position:
                        sortedEmployee = empList.OrderByDescending(em => em.Position).ToList();
                        break;
                    default:
                        sortedEmployee = empList.OrderByDescending(em => em.ID).ToList();
                        break;
                }              
            }
            //Ascending order
            else
            {                
                switch (field)
                {
                    case ESortFiled.PayRate:
                        sortedEmployee = empList.OrderBy(em => em.PayRate).ToList();
                        break;
                    case ESortFiled.Name:
                        sortedEmployee = empList.OrderBy(em => em.Name).ToList();
                        break;
                    case ESortFiled.Position:
                        sortedEmployee = empList.OrderBy(em => em.Position).ToList();
                        break;
                    default:
                        sortedEmployee = empList.OrderBy(em => em.ID).ToList();
                        break;
                }
            }
            //Employee list is sorted
            EmployeeList = sortedEmployee;
        }

        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string caller = null)
        {
            // make sure only to call this if the value actually changes

            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(caller));
            }
        }
        #endregion
    }
}
