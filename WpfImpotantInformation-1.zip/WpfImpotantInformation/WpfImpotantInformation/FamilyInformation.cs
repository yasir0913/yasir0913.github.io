﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


// Vu Nguyen
// Oksana Blagutin
// Harsh Ahluwalia
// Arun Prabu
// Yasir Altahir
//Jon Plumbtree


namespace WpfImpotantInformation
{
    class FamilyInformation : INotifyPropertyChanged
    {
        // private constractor
        private List<Data> addToView;
        private List<Data> _myInfo;
        private List<Data> _fatherInfo;
        private List<Data> _MotherInfo;
        //Lists for the Information
        // My list
        public List<Data> MyInfo
        {
            get { return _myInfo; }
            set { _myInfo = value; OnPropertyChanged(); }
        }
      
        // Father list
        public List<Data> FatherInfo
        {
            get { return _fatherInfo; }
            set { _fatherInfo = value; OnPropertyChanged(); }
        }       
       
        // Mother list
        public List<Data> MotherInfo
        {
            get { return _MotherInfo; }
            set { _MotherInfo = value; OnPropertyChanged(); }
        }       
    
        // Adding the Information to the Lists

        // My information
        public void MyInformation()
        {
 
            addToView = new List<Data>();
            Data obj = new WpfImpotantInformation.Data();
            obj.Name = "Vu";
            obj.Address = "73 Doon St N Kitchener";
            obj.Age="56";
            obj.PhoneNum = "519 888 7777";
            addToView.Add(obj);
            _myInfo = new List<Data>(addToView);
              
        }
        // Father information
        public void FatherInformation()
        {
            addToView = new List<Data>();
            Data obj1 = new WpfImpotantInformation.Data();
            obj1.Name = "Suzuki";
            obj1.Address = "133 Blockline Rd S Toronto";
            obj1.Age = "120";
            obj1.PhoneNum = "00249 123 4567";
            addToView.Add(obj1);
            _fatherInfo = new List<Data>(addToView);

    }
        // Mother information
        public void MotherInformation()
        {
            addToView = new List<Data>();            
            Data obj2 = new WpfImpotantInformation.Data();            
            obj2.Name = "Sara";
            obj2.Address = "133 blockline Rd S Toronto";
            obj2.Age = "57";
            obj2.PhoneNum = "00249 123 4567";
            addToView.Add(obj2);
            _MotherInfo = new List<Data>(addToView);

        }
        
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler eventHandler = this.PropertyChanged;
            if (eventHandler != null)
            {
                eventHandler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
