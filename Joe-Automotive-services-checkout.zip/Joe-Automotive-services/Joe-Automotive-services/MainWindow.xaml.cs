﻿using System.Windows;

namespace Joe_Automotive_services
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Josservice josobj;
        public MainWindow()
        {
            InitializeComponent();
            josobj = new Josservice();
            DataContext = josobj;
        }

        private void btncalculate_Click(object sender, RoutedEventArgs e)
        {

            // josobj.clear();
     
               josobj.Calculate();







        }
    }
}
