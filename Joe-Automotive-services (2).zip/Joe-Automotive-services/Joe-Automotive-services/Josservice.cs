﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Joe_Automotive_services
{
    class Josservice : INotifyPropertyChanged
    {
        // constany value
        const decimal OILCHANGE = 26;
        const decimal LUBJOB    = 18;
        const decimal RADIATORFLUSH = 30;
        const decimal TRANSMISSIONFLUSH = 80;
        const decimal INSPACTION = 15;
        const decimal MUFFLERREPLACE = 100;
        const decimal TIREROTATION = 20;
        const decimal LABORCHARGE = 50;
      
        //variable
       // public decimal taxamount ;
        public decimal totalprice ;
        public bool Oilchange
        {
            get { return _oilchange; }
            set {
                _oilchange = value;
               
                Notify("Oilchange");
                 
            }
        }
        private bool _oilchange;

        public bool Lubejob
        {
            get { return _lubejob; }
            set
            {
                _lubejob = value;

                Notify("Lubejob");
            }
        }
        private bool _lubejob;

        public bool Radiatorflush
        {
            get { return _radiatorflush; }
            set
            {
                _radiatorflush = value;

                Notify("Radiatorflush");
            }
        }
        private bool _radiatorflush;

        public bool Transmissionflush
        {
            get { return  _transmissionflush; }
            set
            {
                _transmissionflush = value;

                Notify("Transmissionflush");
            }
        }
        private bool _transmissionflush;

        public bool Inspection
        {
            get { return _inspection; }
            set
            {
                _inspection = value;
            
                Notify("Inspection");
            }
        }
        private bool _inspection;

        public bool Mufflerreplace
        {
            get { return _mufflerreplace; }
            set
            {
                _mufflerreplace = value;

                Notify("Mufflerreplace");
            }
        }
        private bool _mufflerreplace;

        public bool Tirerotation
        {
            get { return _tirerotation; }
            set
            {
                _tirerotation = value;

                Notify("Tirerotation");
            }
        }
        private bool _tirerotation;

        public Decimal Partprice
        {
            get { return _partprice; }
            set { _partprice = value; Notify("Partprice"); }
        }
        private decimal _partprice;

        public Decimal  Laborhours
        {
            get { return _laborhours; }
            set { _laborhours = value; Notify("Laborhours"); }
        }
        private decimal _laborhours;

        public Decimal  Totalprice
        {
            get { return _totalprice; }
            set { _totalprice = value; Notify("Totalprice"); }
        }
        private decimal _totalprice;

        
 

        // Calcutation Function
        public void Calculate()
        {
            if (_oilchange)
                totalprice += OILCHANGE;
            if (_lubejob)
                totalprice += LUBJOB;
            if (_radiatorflush)
                totalprice += RADIATORFLUSH;
            if (_transmissionflush)
                totalprice += TRANSMISSIONFLUSH;
            if (_inspection)
                totalprice += INSPACTION;
            if (_mufflerreplace)
                totalprice += MUFFLERREPLACE;
            if (_tirerotation)
            {
                totalprice += TIREROTATION;
            }
            totalprice += (_laborhours * LABORCHARGE);
            
            _totalprice = totalprice;
        }

        //Clear Function
        public void clear()
        {
           // totalprice = 0;
            //_laborhours = 0;
        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected void Notify(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
