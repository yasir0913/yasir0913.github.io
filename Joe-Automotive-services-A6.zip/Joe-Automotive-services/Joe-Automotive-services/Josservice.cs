﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Assigntment 2 Group 2
// Vu Nguyen
// Oksana Blagutin
// Harsh Ahluwalia
// Arun Prabhu
// Jon Plumbtree
// Yasir Altahir

namespace Joe_Automotive_services
{
    class Josservice : INotifyPropertyChanged
    {
        // constany value
        const decimal OILCHANGE = 26m;
        const decimal LUBJOB    = 18m;
        const decimal RADIATORFLUSH = 30m;
        const decimal TRANSMISSIONFLUSH = 80m;
        const decimal INSPACTION = 15m;
        const decimal MUFFLERREPLACE = 100m;
        const decimal TIREROTATION = 20m;
        const decimal LABORCHARGE = 20m;
        const decimal TAXPERCENTAGE = 0.06m;
                       
        // check the checked service and bind
        public bool Oilchange
        {
            get { return _oilchange; }
            set {
                _oilchange = value;               
                Notify("Oilchange");                 
            }
        }
        private bool _oilchange;

        public bool Lubejob
        {
            get { return _lubejob; }
            set
            {
                _lubejob = value;
                Notify("Lubejob");
            }
        }
        private bool _lubejob;

        public bool Radiatorflush
        {
            get { return _radiatorflush; }
            set
            {
                _radiatorflush = value;
                Notify("Radiatorflush");
            }
        }
        private bool _radiatorflush;

        public bool Transmissionflush
        {
            get { return  _transmissionflush; }
            set
            {
                _transmissionflush = value;
                Notify("Transmissionflush");
            }
        }
        private bool _transmissionflush;

        public bool Inspection
        {
            get { return _inspection; }
            set
            {
                _inspection = value;            
                Notify("Inspection");
            }
        }
        private bool _inspection;

        public bool Mufflerreplace
        {
            get { return _mufflerreplace; }
            set
            {
                _mufflerreplace = value;
                Notify("Mufflerreplace");
            }
        }
        private bool _mufflerreplace;
        
        public bool Tirerotation
        {
            get { return _tirerotation; }
            set
            {
                _tirerotation = value;
                Notify("Tirerotation");
            }
        }
        private bool _tirerotation;

        //Decimal properties
        public Decimal Partprice
        {
            get { return _partprice; }
            set { _partprice = value; Notify("Partprice"); }
        }
        private decimal _partprice = 0;

        public Decimal  Laborhours
        {
            get { return _laborhours; }
            set { _laborhours = value; Notify("Laborhours"); }
        }
        private decimal _laborhours = 0;

        public Decimal  Totalprice
        {
            get { return _totalprice; }
            set { _totalprice = value; Notify("Totalprice"); }
        }
        private decimal _totalprice = 0;
        
        //There should be another binding control ??
        public Decimal Taxamount
        {
            get { return _taxamount; }
            set { _taxamount = value; Notify("Taxamount"); }
        }
        private decimal _taxamount = 0;

        #region ChargeCalculation
        // Main calcutation function
        public void Calculate()
        {
            //Clears the tax and total area of the form.
            ClearTaxAndTotal();

            //Calculates the total charges
            Totalprice = TotalCharges();
        }        

        //Returns the total charges for an oil change and/or a lube job, if any.
        public decimal OilLubeCharges()
        {
            decimal chargeCurrent = 0m;
            
            if (_oilchange)
                chargeCurrent = OILCHANGE;
            if (_lubejob)
                chargeCurrent += LUBJOB;

            return chargeCurrent;
        }
        //Returns the total charges for a radiator flush and/or a transmission flush, if any.
        public decimal FlushCharges()
        {
            decimal chargeCurrent = 0m;

            if (_radiatorflush)
                chargeCurrent = RADIATORFLUSH;
            if (_transmissionflush)
                chargeCurrent += TRANSMISSIONFLUSH;

            return chargeCurrent;
        }
        //Returns the total charges for an inspection, muffler replacement, and/or a tire
        public decimal MiscCharges()
        {
            decimal chargeCurrent = 0m;

            if (_inspection)
                chargeCurrent = INSPACTION;
            if (_mufflerreplace)
                chargeCurrent += MUFFLERREPLACE;
            if (_tirerotation)
                chargeCurrent += TIREROTATION;

            return chargeCurrent;
        }
        //Returns the total charges for other services (parts and labor, if any)
        public decimal OtherCharges()
        {     
            return _laborhours * LABORCHARGE + _partprice;
        }
        //Returns the amount of sales tax, if any. Sales tax is 6% and is charged only on parts.
        public decimal TaxCharges()
        {  
            return TAXPERCENTAGE * _partprice;
        }
        //Returns the total charges.
        public decimal TotalCharges()
        {
            decimal chargeCurrent = 0m;

            Taxamount = TaxCharges();            
            chargeCurrent += OilLubeCharges();
            chargeCurrent += FlushCharges();
            chargeCurrent += MiscCharges();
            chargeCurrent += OtherCharges();
            chargeCurrent += Taxamount;

            return chargeCurrent;
        }
        #endregion

        #region ClearData

        //Clear Function
        public void ClearOilLube()
        {
            Oilchange = false;
            Lubejob = false;
        }
        public void ClearFlushes()
        {
            Radiatorflush = false;
            Transmissionflush = false;
        }
        public void ClearMisc()
        {
            Inspection = false;
            Mufflerreplace = false;
            Tirerotation = false;
        }
        public void ClearOther()
        {
            Partprice = 0;
            Laborhours = 0;
        }
        public void ClearTaxAndTotal()
        {
            Totalprice = 0;
            Taxamount = 0;           
        }
        public void ClearData()
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearTaxAndTotal();
        }
        #endregion

        public event PropertyChangedEventHandler PropertyChanged;
        protected void Notify(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}
